#pragma once

void CardsDeckTest();